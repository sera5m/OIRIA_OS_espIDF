#include "freertos/FreeRTOS.h"      // MUST be first
#include "freertos/queue.h"
#include "freertos/task.h"
#include "os_code/core/rShell/enviroment/env_vars.h"
#include "hardware/drivers/generic/button_driver.hpp"
#include "os_code/middle_layer/input/input_handler.hpp"
#include "esp_log.h"
#include "esp_timer.h"
#include <memory>
#include "os_code/middle_layer/input/hid_t.h"
#include "tusb.h"
#include "class/hid/hid.h"
#include "device/usbd_pvt.h"
static const char* TAG = "InputHandler";
#include "os_code/applications/toolkit/RemoteKeyboard/keymap.hpp"



extern QueueHandle_t ProcInputQueTarget;
DeviceManager gDeviceManager;
static const uint8_t hid_report_descriptor[] = {
    TUD_HID_REPORT_DESC_KEYBOARD(HID_REPORT_ID(1)),
    TUD_HID_REPORT_DESC_MOUSE(HID_REPORT_ID(2))
};

// REMOVE these lines - they're causing redefinition:
// extern bool usb_hid_enabled=0; //declared in hpp
// static bool usb_hid_enabled = false;

// Define it ONCE (not extern, not static)
bool usb_hid_enabled = false;


static TaskHandle_t s_input_task_handle = NULL;

// Function to be called from encoder ISR
void IRAM_ATTR encoder_isr_notify(void *ctx) {
    TaskHandle_t task = s_input_task_handle;
    if (task) {
        BaseType_t higherPriorityTaskWoken = pdFALSE;
        vTaskNotifyGiveFromISR(task, &higherPriorityTaskWoken);
        portYIELD_FROM_ISR(higherPriorityTaskWoken);
    }
}

// ====================== USB HID SUPPORT ======================


bool is_usb_hid_enabled(void) {
    return usb_hid_enabled;
}

void boot_hid_usb(bool enable)
{
    usb_hid_enabled = enable;
    if (enable) {
        ESP_LOGI(TAG, "USB HID Mode ACTIVATED (Keyboard + Mouse)");
        
        // don't think we need this at all because it's defined in tusb_config or tusb_descriptors.c and we need to change to be able to do it at runtime
       // tud_hid_set_report_descriptor(0, hid_report_descriptor, sizeof(hid_report_descriptor));
        tud_init(0);  // 0 = default RHPORT on ESP32-S3
    } else {
        ESP_LOGI(TAG, "USB HID Mode DISABLED");
    }
}

void hid_send_key(uint8_t keycode, bool pressed)
{
    if (!usb_hid_enabled || !tud_hid_ready()) return;

    uint8_t report[8] = {0};
    if (pressed) report[2] = keycode;

    tud_hid_report(0, report, sizeof(report));  // Report ID 0 = Keyboard
}

void hid_send_mouse_old(int8_t dx, int8_t dy, uint8_t buttons)
{
    if (!usb_hid_enabled || !tud_hid_ready()) return;

    uint8_t report[5] = {buttons, (uint8_t)dx, (uint8_t)dy, 0, 0};
    tud_hid_report(1, report, 5);   // Report ID 1 = Mouse
}

void hid_send_mouse(int8_t dx, int8_t dy, uint8_t buttons)
{
    if (!usb_hid_enabled) return;
    if (!tud_hid_ready()) return;

     // Parameters: report_id, buttons, x_offset, y_offset, vertical_wheel, horizontal_wheel
    tud_hid_mouse_report(HID_ITF_PROTOCOL_MOUSE, buttons, dx, dy, 0, 0);
}

// TinyUSB Callbacks
//extern "C" {
    uint16_t tud_hid_get_report_cb(uint8_t itf, uint8_t report_id,
                                   hid_report_type_t report_type, uint8_t* buffer, uint16_t reqlen)
    {
        return 0;
    }

    void tud_hid_set_report_cb(uint8_t itf, uint8_t report_id,
                               hid_report_type_t report_type, uint8_t const* buffer, uint16_t bufsize)
    {
        // Optional
    }
//}

uint8_t get_hid_keycode(uint16_t custom_key, uint8_t* modifiers) {
    *modifiers = 0;
    switch (custom_key) {
        case KEY_UP:    return HID_KEY_ARROW_UP;
        case KEY_DOWN:  return HID_KEY_ARROW_DOWN;
        case KEY_LEFT:  return HID_KEY_ARROW_LEFT;
        case KEY_RIGHT: return HID_KEY_ARROW_RIGHT;
        case KEY_ENTER: return HID_KEY_ENTER;
        case KEY_BACK:  return HID_KEY_ESCAPE;   // or HID_KEY_BACKSPACE
        default:        return 0;
    }
}

void hid_send_key_with_modifiers(uint8_t keycode, uint8_t modifiers, bool pressed)
{
    if (!usb_hid_enabled || !tud_hid_ready()) return;

    uint8_t report[8] = {0};

    if (pressed) {
        report[0] = modifiers;        // Modifier byte
        report[2] = keycode;          // First key slot
    }

    tud_hid_report(0, report, 8);     // Keyboard report
}

void RouteInput_HidTarget(InputEvent i_ev)
{
    if (!usb_hid_enabled || !tud_hid_ready()) return;

    if (i_ev.action == KeyAction::PositionDelta) {
        hid_send_mouse(0, i_ev.delta * 3, 0);
        return;
    }

    uint8_t modifiers = 0;
    uint8_t hid_code = get_hid_keycode(i_ev.key, &modifiers);

    if (hid_code == 0) return;

    bool pressed = (i_ev.action == KeyAction::Tap || i_ev.action == KeyAction::Press);
    hid_send_key_with_modifiers(hid_code, modifiers, pressed);
}







// ===================================================================
// ButtonDevice
// ===================================================================
esp_err_t ButtonDevice::initialize(const button_config_t* cfg)
{
    if (btn_handle) {
        button_del(btn_handle);
        btn_handle = nullptr;
    }
    if (!cfg) return ESP_ERR_INVALID_ARG;

    button_config_t local = *cfg;
    local.on_press   = pressCallback;
    local.on_release = releaseCallback;   // was nullptr — required for Tap/Hold
    local.user_ctx   = this;

    pressed_ = false;
    hold_sent_ = false;
    press_start_ms_ = 0;
    last_hold_ms_ = 0;

    return button_new(&local, &btn_handle);
}

ButtonDevice::~ButtonDevice()
{
    if (btn_handle) button_del(btn_handle);
}

void ButtonDevice::enqueue(KeyAction action)
{
    InputEvent ev{};
    ev.target = (HIDTarget)v_env.CurrentHIDTarget;
    ev.source_device_type = HIDInputDeviceType::Button;
    ev.key = props.press_key;
    ev.action = action;
    ev.timestamp = (uint32_t)(esp_timer_get_time() / 1000);
    if (ProcInputQueTarget) {
        xQueueSend(ProcInputQueTarget, &ev, pdMS_TO_TICKS(10));
    }
}

void ButtonDevice::pressCallback(void* user_ctx, bool pressed)
{
    auto* self = static_cast<ButtonDevice*>(user_ctx);
    if (!self || !pressed) return;

    self->pressed_ = true;
    self->hold_sent_ = false;
    self->press_start_ms_ = (uint32_t)(esp_timer_get_time() / 1000);
    self->last_hold_ms_ = self->press_start_ms_;

    // Optional immediate Press for apps that want edge-down
    if (self->props.send_on_press) {
        self->enqueue(KeyAction::Press);
    }
}

void ButtonDevice::releaseCallback(void* user_ctx, bool /*pressed*/)
{
    auto* self = static_cast<ButtonDevice*>(user_ctx);
    if (!self) return;

    const bool was_held = self->hold_sent_;
    self->pressed_ = false;

    if (!was_held) {
        // Short click → Tap (what most menu / nav code expects)
        self->enqueue(KeyAction::Tap);
    } else {
        // Long press ending
        self->enqueue(KeyAction::Release);
    }
    self->hold_sent_ = false;
}

void ButtonDevice::update()
{
    if (btn_handle) button_poll(btn_handle);

    if (!pressed_ || hold_sent_) {
        // still poll for release; if hold_repeat, allow re-fire below
        if (!(pressed_ && props.hold_repeat && hold_sent_))
            return;
    }

    uint32_t now = (uint32_t)(esp_timer_get_time() / 1000);
    uint32_t held = now - press_start_ms_;

    if (!hold_sent_ && held >= props.hold_ms) {
        hold_sent_ = true;
        last_hold_ms_ = now;
        enqueue(KeyAction::Hold);
        return;
    }

    if (props.hold_repeat && hold_sent_ &&
        (now - last_hold_ms_) >= props.hold_ms) {
        last_hold_ms_ = now;
        enqueue(KeyAction::Hold);
    }
}

void ButtonDevice::interact(Device& other) { (void)other; }




// ===================================================================
// KnobDevice
// ===================================================================

void register_input_task_for_notifications(TaskHandle_t task) {
    s_input_task_handle = task;
}


esp_err_t KnobDevice::initialize(const ky040_config_t* cfg){

    

    if (ky_handle) {
        ky040_del(ky_handle);
        ky_handle = nullptr;
    }
    if (!cfg) return ESP_ERR_INVALID_ARG;

    ky040_config_t local = *cfg;
    local.on_twist = twistCallback;
    local.user_ctx = this;

    //interrupt allow mode requires filling additional fields automatically
    if (cfg->use_interrupt) {
        local.use_interrupt = true;
        local.on_pcnt_interrupt = encoder_isr_notify;
    }


    esp_err_t ret = ky040_new(&local, &ky_handle);
    if (ret == ESP_OK) {
        ESP_LOGI(TAG, "KnobDevice initialized");
    } else {
        ESP_LOGE(TAG, "ky040_new failed: %s", esp_err_to_name(ret));
    }
    return ret;
}

KnobDevice::~KnobDevice()
{
    if (ky_handle) ky040_del(ky_handle);
}

void KnobDevice::update()
{
    if (ky_handle) ky040_poll(ky_handle);
}

void KnobDevice::twistCallback(void* user_ctx, int delta)
{
    ESP_LOGI(TAG, "twistcallback");
    if (!user_ctx) return;

    auto* self = static_cast<KnobDevice*>(user_ctx);

    InputEvent ev{};
    ev.target = (HIDTarget)v_env.CurrentHIDTarget;
    ev.source_device_type = HIDInputDeviceType::Knob;
    ev.timestamp = (uint32_t)(esp_timer_get_time() / 1000);
    ev.delta = delta;

    if (self->props.send_delta_instead_of_keys) {
        ev.action = KeyAction::PositionDelta;
    } else {
        ev.key    = (delta > 0) ? self->props.cw_key : self->props.ccw_key;
        ev.action = KeyAction::Tap;
    }

    if (ProcInputQueTarget) {
        xQueueSend(ProcInputQueTarget, &ev, pdMS_TO_TICKS(10));
    }
}

void KnobDevice::interact(Device& other) {}

// ===================================================================
// DeviceManager
// ===================================================================





// Add these implementations to input_handler.cpp

void DeviceManager::updateEncoder() {
    for (auto& dev : devices) {
        if (dev->getType() == HIDInputDeviceType::Knob) {
            dev->update();
        }
    }
}

void DeviceManager::updateButtons() {
    for (auto& dev : devices) {
        if (dev->getType() == HIDInputDeviceType::Button) {
            dev->update();
        }
    }
}



void DeviceManager::addDevice(std::unique_ptr<Device> device)
{
    if (!device) {
        ESP_LOGE(TAG, "addDevice: received null device");
        return;
    }

    const char* name = device->getName();
    devices.push_back(std::move(device));

    ESP_LOGI(TAG, "Added device: %s (type %d)", name, (int)devices.back()->getType());
}

void DeviceManager::updateAll()
{
    for (auto& dev : devices) {
        dev->update();
    }
}

void DeviceManager::removeDevice(const char* name) {
    auto it = std::remove_if(devices.begin(), devices.end(),
        [name](const std::unique_ptr<Device>& dev) {
            return strcmp(dev->getName(), name) == 0;
        });
    devices.erase(it, devices.end());
}

void DeviceManager::listDevices() {
    ESP_LOGI("DeviceManager", "Connected devices: %d", devices.size());
    for (auto& dev : devices) {
        ESP_LOGI("DeviceManager", "  - %s (type %d)", dev->getName(), (int)dev->getType());
    }
}