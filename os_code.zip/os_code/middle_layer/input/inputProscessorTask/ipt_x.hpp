#pragma once

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"
#include "code_stuff/types.h"
#include "os_code/core/rShell/enviroment/env_vars.h"
#include "os_code/middle_layer/input/hid_t.h"
//note: don't include tusb.h here, it will cause abnormalities with the build system. it's in the cpp anyway.
#include "os_code/core/rShell/streams/rshell_pump.hpp"
#include "esp_log.h"
#include "esp_timer.h"
#include "hardware/drivers/psram_std/psram_std.hpp"
#include "hardware/drivers/sd_card/d_sdc.h"
#include "os_code/core/rShell/rshell_appFramework.hpp"
#include "os_code/core/rShell/rshell_appmanager.hpp"
#include "os_code/core/rShell/streams/rshell_pipe.hpp"
// Forward declaration of InputEvent to break circular include


// Forward declaration
struct InputEvent;

void startInputTask();

// NO queue here - using ProcInputQueTarget from main
// NO callbacks here - those are in input_handler you fucktard dev
// do NOT move input hand ler into here holy fuck this set me back three days of work

//this is an external function and we have to declare this here to access it apparently
void RouteInput_HidTarget(InputEvent i_ev);
